# Škola Online (Čistá verze)

Tato verze je vyčištěná od veškerých ukázkových dat (žáci, známky, zprávy, rozvrh).

## Přihlášení pro správy:
- **Uživatelské jméno:** `admin`
- **Heslo:** `admin`

Po přihlášení můžete v sekci **Účty** změnit heslo i jméno administrátora a vytvořit libovolné další účty (učitelé, žáci, rodiče).
